Athan Alexa Skill:

By Mohamed Aboulela, Jordan Garcia, Zachary Hayes and Connor Hausmann

- The purpose of this skill is to allow for Alexa to be able to perform the Athan (call to prayer) five times a day, every day,
for every prayer.

This skill was crated using python. Our platforms were GitHub Desktop and the Amazon Developer Console.
